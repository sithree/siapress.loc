<?php
#Yii::app()->cache->flush();
$this->layout = '//layouts/news/article';
$this->setPageTitle($model['title']); #; . Yii::app()->name);
$this->addMetaProperty('og:title', $model['title']);
$this->addMetaProperty('og:type', 'article');
$this->addMetaProperty('og:description', $model['introtext']);
$this->addMetaProperty('og:url', 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']);
(is_file('images/news/main/' . $model['id'] . '_item.jpg')) ? $this->addMetaProperty('og:image', 'http://' . $_SERVER['SERVER_NAME'] . '/images/news/main/' . $model['id'] . '_item.jpg') : '';
$this->addMetaProperty('og:site_name', Yii::app()->name);
?>


<?php $this->widget('application.components.main.mbanner', array('position' => 7)); ?>
<article class="hentry">
    <header>
        <?php echo CHtml::tag('h1', array('class' => 'title entry-title'), $model['title']); ?>
        <?php echo strlen($model['introtext']) > 8 ? CHtml::tag('h3', array('class' => 'introtext entry-summary'), $model['introtext']) : ''; ?>
        <time class="published" style="display: none;" datetime="<?php echo date('Y-m-d H:i:s-0600', strtotime($model['publish'])); ?>" pubdate><?php echo date('Y-m-d H:i:s-0600', strtotime($model['publish'])); ?></time>
        <time class="updated" style="display: none;" datetime="<?php echo date('Y-m-d H:i:s-0600', strtotime($model['publish'])); ?>" update><?php echo date('Y-m-d H:i:s-0600', strtotime($model['publish'])); ?></time>
        <div class="tags" style="display: none;"><?php echo $model['tags']; ?></div>
    </header>

    <p style="text-align: right; margin-top: 10px">
        <a href="<?php echo Yii::app()->request->getHostInfo() . Yii::app()->request->getRequestUri() ?>#comments">Перейти к комментариям</a>
    </p>

    <hr />
    <?php #$this->widget('application.components.main.mbanner', array('position' => 7)); ?>

    <?php # echo Article::model()->getArticleimage($model); ?>

    <?php
    $this->widget('application.extensions.fancybox.EFancyBox', array(
        'target' => 'a[rel=gallery]',
        'config' => array(),
            )
    );
    ?>




    <div class='entry-content'>
        <?php
        if (is_file('images/news/main/' . $model['id'] . '_item.jpg')):
            if (is_file('images/news/main/' . $model['id'] . '.jpg')):
                ?>
                <div class="news-image-container">
                    <figure style="margin: 0;">
                        <a title="<?php echo ($model['imgtitle']) ? CHtml::encode($model['imgtitle']) : CHtml::encode($model['title']) ?>" rel="gallery" href="images/news/main/<?php echo $model['id'] ?>.jpg">
                            <img title="<?php echo CHtml::encode($model['title']) ?>" alt="<?php echo CHtml::encode($model['title']) ?>" src="images/news/main/<?php echo $model['id'] ?>_item.jpg" class="newsimage" /></a>
                        <?php if ($model['imgtitle']): ?>
                            <figcaption><span class="imgtitle"><?php echo CHtml::encode($model['imgtitle']) ?></span></figcaption>
                        <?php endif; ?>
                    </figure>
                </div>
            <?php else: ?>
                <div class="news-image-container">
                    <figure style="margin: 0;">
                        <img alt="<?php echo CHtml::encode($model['title']) ?>" src="images/news/main/<?php echo $model['id'] ?>_item.jpg" class="newsimage" />
                        <?php if ($model['imgtitle']): ?>
                            <figcaption><span class="imgtitle"><?php echo CHtml::encode($model['imgtitle']) ?></span></figcaption>
                        <?php endif; ?>
                    </figure>
                </div>
            <?php
            endif;
        endif;
        ?>
        <div class="fulltext">
            <?php echo $model['fulltext'] ?>
        </div>
    </div>


    <?php if ($photos): ?>
        <hr />
        <div id="ph" class="row-fluid">
            <?php
            foreach ($photos[1] as $key => $photo):
                ?>
                <div class="exclusive">
                    <a rel="gallery" href="<?php echo $photos[0][$key]; ?>" style="display: block; background: #fbfbfb; width: 100%; height: 100%;" classs="ex_link">
                        <div class="news-image-container"><img alt="<?php $item['title'] ?>" src="<?php echo $photo; ?>" class="newsimage"><span class="imgtitle"></span></div>
                        <div class="ex_cont" style="margin-top: 123px;">
                            <div class="ex_head">Увеличить</div>
                            <div class="ex_desc"></div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    endif;
    ?>
    <br />

    <p class="byline author vcard">
        <?php echo CHtml::tag('span', array('class' => 'authorbottom fn'), Article::model()->getArticleauthor($model)); ?>
    </p>

    <div class="clr"></div>
    <hr />

    <b><?php echo Helper::getFormattedtime($model['publish']) ?>  [Сургут]</b>, просмотров: <?php echo ($model['hits']) ? $model['hits'] : 'не известно'; ?>, комментариев: <?php echo $model['comment_count'] ?>
</article>
<hr />
<?php
$poll = Poll::model()->find('article_id = ' . $model['id']);
if ($poll):
    ?>
    <div class="row-fluid">
        <div class="span12 poll">
    <?php $this->widget('EPoll', array('poll_id' => $poll->id)); ?>
        </div>
    </div>
<?php endif; ?>

<?php $this->widget('application.components.main.mbanner', array('position' => 14)); ?>

<!-- Социальные кнопки -->
<?php include Yii::getPathOfAlias('application.views.front.social') . DIRECTORY_SEPARATOR . 'social.php'; ?>
<?php #include Yii::app()->basePath . DIRECTORY_SEPARATOR . 'views' . DIRECTORY_SEPARATOR . 'social' . DIRECTORY_SEPARATOR . 'social.php';    ?>
<!-- End.Социальные кнопки -->


<hr />

<a id="comments"></a>
<?php if (count($comments) > 0): ?>
    <div style="margin-bottom: 15px; font-size:14px; font-weight: bold;">Комментарии: <a title="Подписаться на RSS - ленту комментариев этой новости" href="#"><span class="label label-warning">RSS</span></a></div>
<?php else: ?>
    <div style="margin-bottom: 15px; font-size:14px; font-weight: bold;">Комментариев пока нет.</div>
<?php endif; ?>


<?php
if (count($comments) > 0) {
    $this->renderPartial('/comments/comments', array(
        'comments' => $comments,
    ));
}
?>
<hr />
<!-- Форма добавления комментария -->
<?php if (isset($commentform) AND Yii::app()->params->comments == true and $model['comment_on'] == 1): ?>
    <a id="addcomment"></a>
    <?php
    $this->renderPartial('application.views.front.comments._form', array(
        'commentform' => $commentform,
        'model' => $model
    ));
else:
    if (empty($model['comment_ban'])):
        ?>
        <h3>Комментарии закрыты.</h3>
    <?php else: ?>
        <h3><?php echo $model['comment_ban'] ?></h3>
    <?php endif; ?>
<?php endif; ?>